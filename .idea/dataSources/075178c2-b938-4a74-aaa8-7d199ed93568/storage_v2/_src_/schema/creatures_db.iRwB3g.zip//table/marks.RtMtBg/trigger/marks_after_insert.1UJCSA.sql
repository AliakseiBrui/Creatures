create trigger marks_AFTER_INSERT
  after INSERT
  on marks
  for each row
  BEGIN
					UPDATE creatures 
						SET creatures.rating=
							(SELECT AVG(marks.mark_value) 
							FROM marks 
							WHERE marks.creature_id = new.creature_id) 
                        WHERE creatures.id = new.creature_id;
END;

