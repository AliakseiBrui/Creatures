create trigger marks_AFTER_DELETE
  after DELETE
  on marks
  for each row
  BEGIN
					UPDATE creatures 
						SET creatures.rating=
							(SELECT AVG(marks.mark_value) 
							FROM marks 
							WHERE marks.creature_id = old.creature_id) 
                        WHERE creatures.id = old.creature_id;
					UPDATE users
						SET users.status=
							(SELECT AVG(marks.status_component)
							FROM marks
                            WHERE marks.user_id = old.user_id)
						WHERE users.id = old.user_id;
END;

