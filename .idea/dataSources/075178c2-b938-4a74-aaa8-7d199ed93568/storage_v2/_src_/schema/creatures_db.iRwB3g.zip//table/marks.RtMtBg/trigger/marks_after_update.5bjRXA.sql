create trigger marks_AFTER_UPDATE
  after UPDATE
  on marks
  for each row
  BEGIN
					UPDATE creatures 
						SET creatures.rating=
							(SELECT AVG(marks.mark_value) 
							FROM marks 
							WHERE marks.creature_id = new.creature_id) 
                        WHERE creatures.id = new.creature_id;
					UPDATE users
						SET users.status=
							(SELECT AVG(marks.status_component)
							FROM marks
                            WHERE marks.user_id = new.user_id)
						WHERE users.id = new.user_id;
END;

